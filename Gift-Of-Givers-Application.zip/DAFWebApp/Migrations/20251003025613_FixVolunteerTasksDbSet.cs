﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DAFWebApp.Migrations
{
    /// <inheritdoc />
    public partial class FixVolunteerTasksDbSet : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
